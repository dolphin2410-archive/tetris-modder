# tetris-killer
## Tetris Automation with Rust WebAssembly

갑자기 테트리스를 자동화 시켜보고 싶어서 만든 프로젝트... 